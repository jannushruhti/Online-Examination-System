var mongoose = require("mongoose");

var traineetestschema = new mongoose.Schema({
    
})